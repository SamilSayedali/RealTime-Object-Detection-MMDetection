"""Real-time object detection using OpenMMLab MMDetection/MMCV."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

import cv2
import mmcv
import numpy as np
import torch
from mmdet.apis import DetInferencer

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_MODEL = "rtmdet_tiny_8xb32-300e_coco"


def build_inferencer(model: str, device: str) -> DetInferencer:
    """Create an MMDetection inferencer; model weights/config are fetched as needed."""
    return DetInferencer(model=model, device=device)


def annotate_frame(
    inferencer: DetInferencer,
    frame: np.ndarray,
    score_thr: float,
    save_dir: Path | None = None,
    frame_index: int | None = None,
) -> tuple[np.ndarray, list[dict[str, Any]]]:
    """Run inference on one BGR frame and return a visualized frame + detections."""
    result = inferencer(inputs=frame, return_vis=True, pred_score_thr=score_thr)
    visualizations = result.get("visualization") or []
    if visualizations:
        rendered = visualizations[0]
        # MMDetection visualization output is RGB; OpenCV display/write expects BGR.
        if rendered.ndim == 3:
            rendered = cv2.cvtColor(rendered, cv2.COLOR_RGB2BGR)
    else:
        rendered = frame.copy()

    predictions = result.get("predictions") or [{}]
    pred = predictions[0] if predictions else {}
    labels = pred.get("labels", [])
    scores = pred.get("scores", [])
    bboxes = pred.get("bboxes", [])
    classes = inferencer.dataset_meta.get("classes", [])

    detections: list[dict[str, Any]] = []
    for label, score, bbox in zip(labels, scores, bboxes):
        label_id = int(label)
        detections.append({
            "class_id": label_id,
            "class_name": classes[label_id] if label_id < len(classes) else str(label_id),
            "confidence": round(float(score), 4),
            "bbox_xyxy": [round(float(v), 2) for v in bbox],
        })

    if save_dir is not None and frame_index is not None:
        save_dir.mkdir(parents=True, exist_ok=True)
        mmcv.imwrite(rendered, str(save_dir / f"frame_{frame_index:06d}.jpg"))
    return rendered, detections


def run_image(inferencer: DetInferencer, source: Path, output_dir: Path, score_thr: float) -> None:
    if not source.is_file():
        raise FileNotFoundError(f"Image not found: {source}")
    frame = mmcv.imread(str(source), channel_order="bgr")
    if frame is None:
        raise ValueError(f"Could not read image: {source}")
    rendered, detections = annotate_frame(inferencer, frame, score_thr)
    output_dir.mkdir(parents=True, exist_ok=True)
    image_out = output_dir / f"{source.stem}_detected.jpg"
    json_out = output_dir / f"{source.stem}_detections.json"
    mmcv.imwrite(rendered, str(image_out))
    json_out.write_text(json.dumps(detections, indent=2), encoding="utf-8")
    print(f"[OK] Annotated image: {image_out}")
    print(f"[OK] Detection data:  {json_out}")
    print(f"[INFO] Objects detected: {len(detections)}")


def run_stream(
    inferencer: DetInferencer,
    source: str,
    output_dir: Path,
    score_thr: float,
    save_video: bool,
) -> None:
    camera_source: int | str = int(source) if source.isdigit() else source
    cap = cv2.VideoCapture(camera_source)
    if not cap.isOpened():
        raise RuntimeError(f"Could not open video/camera source: {source}")

    fps = cap.get(cv2.CAP_PROP_FPS)
    if not fps or fps <= 1 or fps > 120:
        fps = 25.0
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    writer = None
    if save_video:
        output_dir.mkdir(parents=True, exist_ok=True)
        video_path = output_dir / "detection_output.mp4"
        writer = cv2.VideoWriter(
            str(video_path), cv2.VideoWriter_fourcc(*"mp4v"), fps, (width, height)
        )
        if not writer.isOpened():
            cap.release()
            raise RuntimeError("Could not create output video. Check the OpenCV video codec.")
        print(f"[INFO] Saving annotated video to: {video_path}")

    frame_index = 0
    print("[INFO] Press 'q' to stop the video/camera window.")
    try:
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            rendered, detections = annotate_frame(inferencer, frame, score_thr)
            cv2.putText(
                rendered,
                f"Objects: {len(detections)} | Threshold: {score_thr:.2f}",
                (15, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (40, 220, 40), 2,
                cv2.LINE_AA,
            )
            cv2.imshow("OpenMMLab Real-Time Object Detection", rendered)
            if writer is not None:
                writer.write(rendered)
            frame_index += 1
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break
    finally:
        cap.release()
        if writer is not None:
            writer.release()
        cv2.destroyAllWindows()
    print(f"[INFO] Processed frames: {frame_index}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Detect objects in an image, video, or webcam using OpenMMLab."
    )
    parser.add_argument("--source", required=True,
                        help="Path to an image/video, or webcam index (usually 0).")
    parser.add_argument("--model", default=DEFAULT_MODEL,
                        help=f"MMDetection model alias (default: {DEFAULT_MODEL}).")
    parser.add_argument("--device", default="cuda:0" if torch.cuda.is_available() else "cpu",
                        help="Inference device, e.g. cuda:0 or cpu.")
    parser.add_argument("--score-thr", type=float, default=0.35,
                        help="Minimum confidence score between 0 and 1 (default: 0.35).")
    parser.add_argument("--output-dir", type=Path, default=ROOT / "outputs",
                        help="Directory for generated results.")
    parser.add_argument("--save-video", action="store_true",
                        help="Save an annotated MP4 when processing a video/webcam.")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if not 0.0 <= args.score_thr <= 1.0:
        print("Error: --score-thr must be between 0 and 1.", file=sys.stderr)
        return 2
    source_path = Path(args.source)
    is_image = source_path.suffix.lower() in {".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff"}
    try:
        print(f"[INFO] Loading model: {args.model}")
        print(f"[INFO] Device: {args.device}")
        inferencer = build_inferencer(args.model, args.device)
        if is_image:
            run_image(inferencer, source_path, args.output_dir, args.score_thr)
        else:
            run_stream(inferencer, args.source, args.output_dir, args.score_thr, args.save_video)
    except Exception as exc:  # Keep CLI errors readable for first-time users.
        print(f"[ERROR] {exc}", file=sys.stderr)
        print("See README.md -> Troubleshooting for installation guidance.", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
