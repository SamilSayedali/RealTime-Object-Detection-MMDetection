#!/usr/bin/env bash
set -e
# Run this after installing PyTorch in the active object-detection environment.
python -m pip install -U openmim
mim install 'mmengine>=0.7.1,<1.0.0'
mim install 'mmcv>=2.0.0,<2.2.0'
mim install 'mmdet==3.3.0'
python -m pip install -r requirements.txt
echo 'OpenMMLab dependencies installed. Check README.md before running.'
