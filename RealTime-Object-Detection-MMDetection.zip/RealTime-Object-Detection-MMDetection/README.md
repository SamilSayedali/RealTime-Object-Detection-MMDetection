# Real-Time Object Detection with OpenMMLab

A practical computer-vision application that detects and labels everyday objects in images, video files, and a live webcam feed. It uses **MMDetection** for pretrained object-detection models and **MMCV** for image I/O and OpenMMLab's supporting computer-vision utilities.

> **Project status:** Source code and setup instructions are prepared. The full OpenMMLab stack and pretrained model weights must be installed/downloaded on the machine where you run it. This repository has not been runtime-tested in your local environment.

## What it does

- Detects objects in a still image and saves an annotated image.
- Displays live detections from a webcam.
- Processes a video file frame by frame.
- Optionally saves an annotated MP4 for video/webcam input.
- Exports image detections to JSON with class name, confidence score, and bounding-box coordinates.
- Uses a pretrained RTMDet-Tiny model trained on the COCO dataset by default.

## Example use cases

- Counting and locating common objects in a scene.
- Prototyping a smart-camera or visual-inspection workflow.
- Learning the inference pipeline used in modern object-detection systems.

This is a general-purpose demo, not a safety-critical surveillance, medical, or identity-recognition system.

## Technology stack

- Python
- PyTorch
- OpenMMLab MMDetection
- MMCV 2.x and MMEngine
- OpenCV

## Repository structure

```text
RealTime-Object-Detection-MMDetection/
├── configs/
│   └── default.yaml
├── src/
│   └── detector.py
├── tests/
│   └── test_project_structure.py
├── outputs/                 # Generated results (kept empty in Git)
├── .gitignore
├── environment.yml
├── install_openmmlab_windows.bat
├── install_openmmlab_linux_mac.sh
├── requirements.txt
├── LICENSE
└── README.md
```

## Installation

### 1. Create an environment

Python 3.10 is a practical starting point for this OpenMMLab stack. A dedicated environment is strongly recommended.

**Conda (Windows, Linux, or macOS):**

```bash
conda create -n object-detection python=3.10 -y
conda activate object-detection
```

### 2. Install PyTorch

Install the PyTorch build that matches your operating system and CUDA setup by following the official selector: <https://pytorch.org/get-started/locally/>.

For a CPU-only installation, the PyTorch selector provides the correct command. Do not install a random CUDA build: the PyTorch/CUDA combination must match the available driver and OpenMMLab wheel.

### 3. Install OpenMMLab

After PyTorch is installed and the environment is active:

```bash
python -m pip install -U openmim
mim install "mmengine>=0.7.1,<1.0.0"
mim install "mmcv>=2.0.0,<2.2.0"
mim install "mmdet==3.3.0"
```

Then install the remaining project dependencies:

```bash
python -m pip install -r requirements.txt
```

**Important:** MMCV contains compiled CPU/CUDA operators. If MIM cannot find a compatible prebuilt package for your exact PyTorch and CUDA versions, follow the official MMCV installation guide rather than forcing an incompatible wheel. Do not install `mmcv` and `mmcv-lite` together in the same environment.

## Run the application

Run commands from the repository root.

### Image

```bash
python src/detector.py --source path/to/your_image.jpg
```

Replace `path/to/your_image.jpg` with the actual path to a JPG, PNG, or other supported image. The output image and a JSON file will be saved in `outputs/`.

### Webcam

```bash
python src/detector.py --source 0
```

Press **q** in the preview window to stop.

To save the annotated webcam stream:

```bash
python src/detector.py --source 0 --save-video
```

### Video file

```bash
python src/detector.py --source path/to/video.mp4 --save-video
```

### Change confidence threshold or device

```bash
python src/detector.py --source path/to/your_image.jpg --score-thr 0.50 --device cpu
```

If an NVIDIA GPU and a compatible CUDA-enabled PyTorch installation are available, use `--device cuda:0`.

### Choose another MMDetection model

The `--model` option accepts an MMDetection model alias or a supported config/checkpoint specification. Check the official model zoo and use a model compatible with MMDetection 3.x:

<https://mmdetection.readthedocs.io/en/3.x/model_zoo.html>

Example:

```bash
python src/detector.py --source path/to/your_image.jpg --model rtmdet_tiny_8xb32-300e_coco
```

The first run may download the model configuration and checkpoint and therefore needs internet access.

## Output format

For image input, the application writes:

- `outputs/<image-name>_detected.jpg` — image with detection boxes and labels.
- `outputs/<image-name>_detections.json` — structured detection results.

Example JSON record:

```json
{
  "class_id": 0,
  "class_name": "person",
  "confidence": 0.94,
  "bbox_xyxy": [120.4, 45.2, 330.8, 470.1]
}
```

Bounding boxes use `[x_min, y_min, x_max, y_max]` pixel coordinates.

## Troubleshooting

- **`mmcv` installation/build error:** Check your Python, PyTorch, CUDA and MMCV compatibility. Use the official OpenMMLab installation guide and MIM.
- **`mmcv._ext` or operator errors:** You may have installed `mmcv-lite`, or an incompatible MMCV wheel. Recreate the environment and install the matching full `mmcv` package.
- **CUDA unavailable:** Run with `--device cpu`, or install a CUDA-enabled PyTorch build compatible with your NVIDIA driver.
- **Camera cannot open:** Close other applications using the webcam and try `--source 1` if another camera index is available.
- **No preview window on a headless server:** Use image input or adapt the application to save frames without calling `cv2.imshow`.
- **Slow webcam inference:** Use a GPU, reduce camera resolution, or select a lighter supported model.

## Acknowledgements and attribution

This application is an independent example built on top of the OpenMMLab ecosystem. It does **not** claim ownership of MMCV, MMDetection, PyTorch, OpenCV, RTMDet, or the COCO dataset.

- MMCV: <https://github.com/open-mmlab/mmcv>
- MMDetection: <https://github.com/open-mmlab/mmdetection>
- MMEngine: <https://github.com/open-mmlab/mmengine>
- RTMDet paper/project resources: <https://github.com/open-mmlab/mmdetection>
- COCO dataset: <https://cocodataset.org/>

Please review the licenses and model/dataset terms of the upstream components and weights before commercial use or redistribution.

## Author

**Your Name** — replace this with your name and add your GitHub profile link before publishing.

## License

The original application code in this repository is provided under the MIT License. Third-party frameworks, pretrained weights, and datasets retain their own licenses and terms. See `LICENSE`.
