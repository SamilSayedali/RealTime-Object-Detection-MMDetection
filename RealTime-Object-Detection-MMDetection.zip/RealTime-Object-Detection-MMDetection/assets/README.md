# Input images

Place your own test images in this folder. Example:

```bash
python src/detector.py --source assets/my_photo.jpg
```

No third-party demo photograph is bundled in this repository.
