@echo off
REM Run this after installing PyTorch in the active object-detection environment.
python -m pip install -U openmim
if errorlevel 1 exit /b 1
mim install "mmengine>=0.7.1,<1.0.0"
if errorlevel 1 exit /b 1
mim install "mmcv>=2.0.0,<2.2.0"
if errorlevel 1 exit /b 1
mim install "mmdet==3.3.0"
if errorlevel 1 exit /b 1
python -m pip install -r requirements.txt
if errorlevel 1 exit /b 1
echo OpenMMLab dependencies installed. Check README.md before running.
