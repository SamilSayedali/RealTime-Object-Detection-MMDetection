from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_required_files_exist():
    for relative in ["README.md", "requirements.txt", "src/detector.py", "configs/default.yaml"]:
        assert (ROOT / relative).is_file(), f"Missing required file: {relative}"


def test_output_directory_exists():
    assert (ROOT / "outputs").is_dir()
